--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_type_transportasi DROP CONSTRAINT tb_type_transportasi_pkey;
ALTER TABLE ONLY public.tb_transportasi DROP CONSTRAINT tb_transportasi_pkey;
ALTER TABLE ONLY public.tb_rute DROP CONSTRAINT tb_rute_pkey;
ALTER TABLE ONLY public.tb_petugas DROP CONSTRAINT tb_petugas_pkey;
ALTER TABLE ONLY public.tb_penumpang DROP CONSTRAINT tb_penumpang_pkey;
ALTER TABLE ONLY public.tb_pemesanan DROP CONSTRAINT tb_pemesanan_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE public.tb_type_transportasi ALTER COLUMN id_type_transportasi DROP DEFAULT;
ALTER TABLE public.tb_transportasi ALTER COLUMN id_type_transportasi DROP DEFAULT;
ALTER TABLE public.tb_transportasi ALTER COLUMN id_transportasi DROP DEFAULT;
ALTER TABLE public.tb_rute ALTER COLUMN id_transportasi DROP DEFAULT;
ALTER TABLE public.tb_rute ALTER COLUMN id_rute DROP DEFAULT;
ALTER TABLE public.tb_petugas ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_petugas ALTER COLUMN id_petugas DROP DEFAULT;
ALTER TABLE public.tb_penumpang ALTER COLUMN id_penumpang DROP DEFAULT;
ALTER TABLE public.tb_pemesanan ALTER COLUMN id_petugas DROP DEFAULT;
ALTER TABLE public.tb_pemesanan ALTER COLUMN id_rute DROP DEFAULT;
ALTER TABLE public.tb_pemesanan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.tb_pemesanan ALTER COLUMN id_pemesanan DROP DEFAULT;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
DROP SEQUENCE public.tb_type_transportasi_id_type_transportasi_seq;
DROP TABLE public.tb_type_transportasi;
DROP SEQUENCE public.tb_transportasi_id_type_transportasi_seq;
DROP SEQUENCE public.tb_transportasi_id_transportasi_seq;
DROP TABLE public.tb_transportasi;
DROP SEQUENCE public.tb_rute_id_transportasi_seq;
DROP SEQUENCE public.tb_rute_id_rute_seq;
DROP TABLE public.tb_rute;
DROP SEQUENCE public.tb_petugas_id_petugas_seq;
DROP SEQUENCE public.tb_petugas_id_level_seq;
DROP TABLE public.tb_petugas;
DROP SEQUENCE public.tb_penumpang_id_penumpang_seq;
DROP TABLE public.tb_penumpang;
DROP SEQUENCE public.tb_pemesanan_id_rute_seq;
DROP SEQUENCE public.tb_pemesanan_id_petugas_seq;
DROP SEQUENCE public.tb_pemesanan_id_pemesanan_seq;
DROP SEQUENCE public.tb_pemesanan_id_pelanggan_seq;
DROP TABLE public.tb_pemesanan;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: tb_pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pemesanan (
    id_pemesanan integer NOT NULL,
    kode_pemesanan character varying,
    tanggal_pemesanan date,
    tempat_pemesanan character varying,
    id_pelanggan integer NOT NULL,
    kode_kursi character varying,
    id_rute integer NOT NULL,
    tujuan character varying,
    tanggal_berangkat date,
    jam_cekin time without time zone,
    jam_berangkat time without time zone,
    total_bayar integer,
    id_petugas integer NOT NULL
);


ALTER TABLE tb_pemesanan OWNER TO postgres;

--
-- Name: tb_pemesanan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pemesanan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pemesanan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: tb_pemesanan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pemesanan_id_pelanggan_seq OWNED BY tb_pemesanan.id_pelanggan;


--
-- Name: tb_pemesanan_id_pemesanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pemesanan_id_pemesanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pemesanan_id_pemesanan_seq OWNER TO postgres;

--
-- Name: tb_pemesanan_id_pemesanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pemesanan_id_pemesanan_seq OWNED BY tb_pemesanan.id_pemesanan;


--
-- Name: tb_pemesanan_id_petugas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pemesanan_id_petugas_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pemesanan_id_petugas_seq OWNER TO postgres;

--
-- Name: tb_pemesanan_id_petugas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pemesanan_id_petugas_seq OWNED BY tb_pemesanan.id_petugas;


--
-- Name: tb_pemesanan_id_rute_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pemesanan_id_rute_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pemesanan_id_rute_seq OWNER TO postgres;

--
-- Name: tb_pemesanan_id_rute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pemesanan_id_rute_seq OWNED BY tb_pemesanan.id_rute;


--
-- Name: tb_penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penumpang (
    id_penumpang integer NOT NULL,
    username character varying,
    password character varying,
    nama_penumpang character varying,
    alamat_penumpang text,
    tanggal_lahir date,
    jenis_kelamin character varying,
    telepon character varying
);


ALTER TABLE tb_penumpang OWNER TO postgres;

--
-- Name: tb_penumpang_id_penumpang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_penumpang_id_penumpang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_penumpang_id_penumpang_seq OWNER TO postgres;

--
-- Name: tb_penumpang_id_penumpang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_penumpang_id_penumpang_seq OWNED BY tb_penumpang.id_penumpang;


--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas integer NOT NULL,
    username character varying,
    password character varying,
    nama_petuas character varying,
    id_level integer NOT NULL
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_petugas_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_petugas_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_petugas_id_level_seq OWNER TO postgres;

--
-- Name: tb_petugas_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_petugas_id_level_seq OWNED BY tb_petugas.id_level;


--
-- Name: tb_petugas_id_petugas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_petugas_id_petugas_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_petugas_id_petugas_seq OWNER TO postgres;

--
-- Name: tb_petugas_id_petugas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_petugas_id_petugas_seq OWNED BY tb_petugas.id_petugas;


--
-- Name: tb_rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_rute (
    id_rute integer NOT NULL,
    tujuan character varying,
    rute_awal character varying,
    rute_akhir character varying,
    harga integer,
    id_transportasi integer NOT NULL
);


ALTER TABLE tb_rute OWNER TO postgres;

--
-- Name: tb_rute_id_rute_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_rute_id_rute_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_rute_id_rute_seq OWNER TO postgres;

--
-- Name: tb_rute_id_rute_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_rute_id_rute_seq OWNED BY tb_rute.id_rute;


--
-- Name: tb_rute_id_transportasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_rute_id_transportasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_rute_id_transportasi_seq OWNER TO postgres;

--
-- Name: tb_rute_id_transportasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_rute_id_transportasi_seq OWNED BY tb_rute.id_transportasi;


--
-- Name: tb_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transportasi (
    id_transportasi integer NOT NULL,
    kode_kursi character varying,
    jumlah_kursi integer,
    keterangan character varying,
    id_type_transportasi integer NOT NULL
);


ALTER TABLE tb_transportasi OWNER TO postgres;

--
-- Name: tb_transportasi_id_transportasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_transportasi_id_transportasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_transportasi_id_transportasi_seq OWNER TO postgres;

--
-- Name: tb_transportasi_id_transportasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_transportasi_id_transportasi_seq OWNED BY tb_transportasi.id_transportasi;


--
-- Name: tb_transportasi_id_type_transportasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_transportasi_id_type_transportasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_transportasi_id_type_transportasi_seq OWNER TO postgres;

--
-- Name: tb_transportasi_id_type_transportasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_transportasi_id_type_transportasi_seq OWNED BY tb_transportasi.id_type_transportasi;


--
-- Name: tb_type_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_type_transportasi (
    id_type_transportasi integer NOT NULL,
    nama_type character varying,
    keterangan character varying
);


ALTER TABLE tb_type_transportasi OWNER TO postgres;

--
-- Name: tb_type_transportasi_id_type_transportasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_type_transportasi_id_type_transportasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_type_transportasi_id_type_transportasi_seq OWNER TO postgres;

--
-- Name: tb_type_transportasi_id_type_transportasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_type_transportasi_id_type_transportasi_seq OWNED BY tb_type_transportasi.id_type_transportasi;


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Name: tb_pemesanan id_pemesanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan ALTER COLUMN id_pemesanan SET DEFAULT nextval('tb_pemesanan_id_pemesanan_seq'::regclass);


--
-- Name: tb_pemesanan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan ALTER COLUMN id_pelanggan SET DEFAULT nextval('tb_pemesanan_id_pelanggan_seq'::regclass);


--
-- Name: tb_pemesanan id_rute; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan ALTER COLUMN id_rute SET DEFAULT nextval('tb_pemesanan_id_rute_seq'::regclass);


--
-- Name: tb_pemesanan id_petugas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan ALTER COLUMN id_petugas SET DEFAULT nextval('tb_pemesanan_id_petugas_seq'::regclass);


--
-- Name: tb_penumpang id_penumpang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penumpang ALTER COLUMN id_penumpang SET DEFAULT nextval('tb_penumpang_id_penumpang_seq'::regclass);


--
-- Name: tb_petugas id_petugas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas ALTER COLUMN id_petugas SET DEFAULT nextval('tb_petugas_id_petugas_seq'::regclass);


--
-- Name: tb_petugas id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas ALTER COLUMN id_level SET DEFAULT nextval('tb_petugas_id_level_seq'::regclass);


--
-- Name: tb_rute id_rute; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute ALTER COLUMN id_rute SET DEFAULT nextval('tb_rute_id_rute_seq'::regclass);


--
-- Name: tb_rute id_transportasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute ALTER COLUMN id_transportasi SET DEFAULT nextval('tb_rute_id_transportasi_seq'::regclass);


--
-- Name: tb_transportasi id_transportasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi ALTER COLUMN id_transportasi SET DEFAULT nextval('tb_transportasi_id_transportasi_seq'::regclass);


--
-- Name: tb_transportasi id_type_transportasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi ALTER COLUMN id_type_transportasi SET DEFAULT nextval('tb_transportasi_id_type_transportasi_seq'::regclass);


--
-- Name: tb_type_transportasi id_type_transportasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_type_transportasi ALTER COLUMN id_type_transportasi SET DEFAULT nextval('tb_type_transportasi_id_type_transportasi_seq'::regclass);


--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2884.dat';

--
-- Data for Name: tb_pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: tb_penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telepon) FROM stdin;
\.
COPY tb_penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telepon) FROM '$$PATH$$/2874.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, username, password, nama_petuas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, username, password, nama_petuas, id_level) FROM '$$PATH$$/2882.dat';

--
-- Data for Name: tb_rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM stdin;
\.
COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM '$$PATH$$/2887.dat';

--
-- Data for Name: tb_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transportasi (id_transportasi, kode_kursi, jumlah_kursi, keterangan, id_type_transportasi) FROM stdin;
\.
COPY tb_transportasi (id_transportasi, kode_kursi, jumlah_kursi, keterangan, id_type_transportasi) FROM '$$PATH$$/2890.dat';

--
-- Data for Name: tb_type_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_type_transportasi (id_type_transportasi, nama_type, keterangan) FROM stdin;
\.
COPY tb_type_transportasi (id_type_transportasi, nama_type, keterangan) FROM '$$PATH$$/2892.dat';

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: tb_pemesanan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pemesanan_id_pelanggan_seq', 1, false);


--
-- Name: tb_pemesanan_id_pemesanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pemesanan_id_pemesanan_seq', 1, false);


--
-- Name: tb_pemesanan_id_petugas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pemesanan_id_petugas_seq', 1, false);


--
-- Name: tb_pemesanan_id_rute_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pemesanan_id_rute_seq', 1, false);


--
-- Name: tb_penumpang_id_penumpang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_penumpang_id_penumpang_seq', 1, false);


--
-- Name: tb_petugas_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_petugas_id_level_seq', 1, false);


--
-- Name: tb_petugas_id_petugas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_petugas_id_petugas_seq', 1, false);


--
-- Name: tb_rute_id_rute_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_rute_id_rute_seq', 1, false);


--
-- Name: tb_rute_id_transportasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_rute_id_transportasi_seq', 1, false);


--
-- Name: tb_transportasi_id_transportasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_transportasi_id_transportasi_seq', 1, false);


--
-- Name: tb_transportasi_id_type_transportasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_transportasi_id_type_transportasi_seq', 1, false);


--
-- Name: tb_type_transportasi_id_type_transportasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_type_transportasi_id_type_transportasi_seq', 1, false);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pemesanan tb_pemesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan
    ADD CONSTRAINT tb_pemesanan_pkey PRIMARY KEY (id_pemesanan);


--
-- Name: tb_penumpang tb_penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penumpang
    ADD CONSTRAINT tb_penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: tb_petugas tb_petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas
    ADD CONSTRAINT tb_petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: tb_rute tb_rute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute
    ADD CONSTRAINT tb_rute_pkey PRIMARY KEY (id_rute);


--
-- Name: tb_transportasi tb_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi
    ADD CONSTRAINT tb_transportasi_pkey PRIMARY KEY (id_transportasi);


--
-- Name: tb_type_transportasi tb_type_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_type_transportasi
    ADD CONSTRAINT tb_type_transportasi_pkey PRIMARY KEY (id_type_transportasi);


--
-- PostgreSQL database dump complete
--

